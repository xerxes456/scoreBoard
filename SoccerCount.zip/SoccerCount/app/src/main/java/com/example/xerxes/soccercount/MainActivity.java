package com.example.xerxes.soccercount;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Chronometer;
import android.os.SystemClock;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    int scoreA = 0;
    int scoreB = 0;
    int shotA = 0;
    int shotB = 0;
    int foulA = 0;
    int foulB = 0;
    int period = 1;
    int xtraTime = 0;


    public void incrGoalA(View view) {
        ++scoreA;
        displayScoreA(scoreA);
    }

    public void incrShotA(View view) {
        ++shotA;
        displayShotA(shotA);
    }

    public void incrFoulsA(View view) {
        ++foulA;
        displayFoulsA(foulA);
    }

    public void incrGoalB(View view) {
        ++scoreB;
        displayScoreB(scoreB);
    }

    public void incrShotB(View view) {
        ++shotB;
        displayShotB(shotB);
    }

    public void incrFoulsB(View view) {
        ++foulB;
        displayFoulsB(foulB);
    }


    public void xtraT(View v) {
        EditText edit = findViewById(R.id.extraTime);
        int xtraTime = Integer.parseInt(edit.getText().toString());
        int stoppedMilliseconds = 0;
        Chronometer mChronometer = findViewById(R.id.chronoMeter1);
        String chronoText = mChronometer.getText().toString();
        String array[] = chronoText.split(":");
        if (array.length == 2) {
            stoppedMilliseconds = (Integer.parseInt(array[0]) * 60 * 1000 + (xtraTime * 60 *1000))
                    + Integer.parseInt(array[1]) * 1000;}

         else if (array.length == 3) {
            stoppedMilliseconds = Integer.parseInt(array[0]) * 60 * 60 * 1000
                    + (Integer.parseInt(array[1]) * 60 * 1000 + (xtraTime * 60 *1000))
                    + Integer.parseInt(array[2]) * 1000;
        }
        mChronometer.setBase(SystemClock.elapsedRealtime()- stoppedMilliseconds);

        }

    public void half (View view) {
        ++period;
        if (period >= 3){
            period = 2;
        }
        xtraTime = 0;
        shotA = 0;
        shotB = 0;
        foulA = 0;
        foulB = 0;
        stopChronometer();
        displayHalf(period);
        theXtraTime(xtraTime);
        displayShotA(shotA);
        displayShotB(shotB);
        displayFoulsA(foulA);
        displayFoulsB(foulB);
    }

    public void start(View view) {
        startChronometer();
        displayHalf(period);
    }


    public void reset(View view) {
        resetChronometer();
        resetEd();
    }


    public void resetEd() {
        scoreA = 0;
        scoreB = 0;
        shotA = 0;
        shotB = 0;
        foulA = 0;
        foulB = 0;
        xtraTime = 0;
        period = 1;
        theXtraTime(xtraTime);
        displayScoreA(scoreA);
        displayScoreB(scoreB);
        displayShotA(shotA);
        displayShotB(shotB);
        displayFoulsA(foulA);
        displayFoulsB(foulB);
        displayHalf(period);

    }

    private void displayScoreA(int number) {
        TextView teamATextView = findViewById(R.id.teamScoreA);
        teamATextView.setText("" + number);
    }

    private void displayShotA(int number) {
        TextView shotATextView = findViewById(R.id.teamShotsA);
        shotATextView.setText("" + number);
    }

    private void displayFoulsA(int number) {
        TextView foulATextView = findViewById(R.id.teamFoulsA);
        foulATextView.setText("" + number);
    }

    private void displayScoreB(int number) {
        TextView teamATextView = findViewById(R.id.teamScoreB);
        teamATextView.setText("" + number);
    }

    private void displayShotB(int number) {
        TextView shotBTextView = findViewById(R.id.teamShotsB);
        shotBTextView.setText("" + number);
    }

    private void displayFoulsB(int number) {
        TextView foulBTextView = findViewById(R.id.teamFoulsB);
        foulBTextView.setText("" + number);
    }

    private void theXtraTime(int number) {
        TextView xtraTimeView = findViewById(R.id.extraTime);
        xtraTimeView.setText("" + number);
    }

    private void displayHalf(int number) {
        TextView teamATextView = findViewById(R.id.one);
        teamATextView.setText("" + number);
    }


    public void startChronometer() {
        ((Chronometer) findViewById(R.id.chronoMeter1)).setBase(SystemClock.elapsedRealtime());
        ((Chronometer) findViewById(R.id.chronoMeter1)).start();
    }

    public void stopChronometer() {
        ((Chronometer) findViewById(R.id.chronoMeter1)).stop();
    }

    public void resetChronometer() {
        ((Chronometer) findViewById(R.id.chronoMeter1)).setBase(SystemClock.elapsedRealtime());
        ((Chronometer) findViewById(R.id.chronoMeter1)).stop();
    }
}
